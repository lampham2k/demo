<?php

$connect = mysqli_connect('db-service:3306','root','root','bao_tri');

$GLOBALS['connect'] = $connect;